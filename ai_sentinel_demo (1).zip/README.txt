
AI Sentinel Demo Prototype
Files:
- synthetic_code_metrics.csv : synthetic dataset for vulnerability predictor
- vuln_clf.pkl, vuln_scaler.pkl : trained RandomForest classifier and scaler
- vuln_summary.json : model accuracy and classification report
- synthetic_api_telemetry.csv : synthetic API telemetry for anomaly detector
- anomaly_iso.pkl : trained IsolationForest model
- anomaly_test_samples.csv : sample rows including injected anomalies and predictions
- exploit_simulator_attempts.csv : simulated SQL-like queries showing potential injections

How to run (python):
- load models with pickle and call predict/decision_function.
- examine anomaly_test_samples.csv to see which rows were flagged as anomalies.
- review exploit_simulator_attempts.csv to see heuristic detection of SQL injection-like payloads.
